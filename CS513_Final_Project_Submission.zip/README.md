# Employee Attrition Analysis

The project was intended to detect potential attrition from a slightly imbalanced dataset. We Performed data analysis and developed machine learning models to detect potential attritions. This dataset was provided by Professor Khasha Dehnad and the accuracy and genuineness of the dataset were never disclosed by the organization who provided the data set to the professor and hence could not be passed on to the students. In this dataset, there were 9612 observations with 27 variables and the attrition year starting from 2004 up till 2017.

## Authors

- **Akhil Manchikanti**
  (https://github.com/akhmanchi/)

- **Meghana Bhat Manikal**
  (https://github.com/MeghanaBhatManikal)

- **Rajat Verma**
  (https://github.com/vermarajat22255)

- **Sanam Sritam Jena**
  (https://github.com/sanamsritam)

## Github Link

https://github.com/akhmanchi/KDD_Final_Project
